/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Frames;

import BeanClasses.BatchBean;
import BeanClasses.Decode;
import BeanClasses.DepartmentBean;
import BeanClasses.Encode;
import BeanClasses.FacultyBean;
import BeanClasses.MainWorkPlace;
import BeanClasses.ProgramBean;
import DatabaseManager.DatabaseManager;
import java.util.List;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author Dell
 */
public class BatchFrame extends javax.swing.JFrame {
    
    DatabaseManager databaseManager= new DatabaseManager();
    
    public BatchFrame() {
        initComponents();
        getFaculty();
    }
    
    private void getFaculty(){
        try{
            List<FacultyBean> faculties = databaseManager.getFaculty();
            JComboFacId.removeAllItems();
            
            for(int i = 0; i < faculties.size(); i++){
                JComboFacId.addItem(faculties.get(i));
            }
        }catch(Exception ee){
            ee.printStackTrace();
            MainWorkPlace.Jpane("Error "+ee.getMessage());
        }
    }
    
    private void getDepartment(){
        
        try{
            FacultyBean beans = (FacultyBean)(JComboFacId.getSelectedItem());  
            List<DepartmentBean> depart = databaseManager.getDepartment(beans.getFacId());
            JComboDeptId.removeAllItems();
            
            for(int i = 0; i < depart.size(); i++){
                JComboDeptId.addItem(depart.get(i));
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }//end of get
    
    private void getProgram(){
        
        try{
            DepartmentBean beans = (DepartmentBean)(JComboDeptId.getSelectedItem()); 
            List<ProgramBean> program = databaseManager.getProgram(beans.getDeptId());
            JComboProgId.removeAllItems();
            
            for(int i = 0; i < program.size(); i++){
                JComboProgId.addItem(program.get(i));
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }//end of get
    
     private void getBatch(){
        
        try{
            ProgramBean beans = (ProgramBean)(JComboProgId.getSelectedItem()); 
            List<BatchBean> program = databaseManager.getBatch(beans.getProgId());
            jList.setListData(program.toArray());
        }catch(Exception e){
            e.printStackTrace();
        }
    }//end of get
    
    private void deleteBatch(){
        
        ProgramBean bean=(ProgramBean)jList.getSelectedValue();
        if(bean==null)return;
       
        try{
            int rows=databaseManager.deleteBatch(bean.getProgId());
            if(rows>=1){
               getBatch();
               clearText();
               JOptionPane.showMessageDialog(this,rows+"record removed");
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }//end of delete
    
    private void updateBatch(){
        
        ProgramBean bean = (ProgramBean)JComboProgId.getSelectedItem();
        int batchId = Integer.parseInt(TbatchId.getText());
        int batchYear = Integer.parseInt(TbatchYear.getText());
        String remarks = remarksArea.getText();
        String batchShift = Encode.shiftEncode(JComboShift.getSelectedItem().toString());
        String batchGroup = Encode.groupEncode(JComboGroup.getSelectedItem().toString());
        
        try{
            int rows = databaseManager.updateBatch(new BatchBean(bean.getProgId(),batchId,batchYear,batchShift,batchGroup, remarks));
            if(rows >= 1){
                JOptionPane.showMessageDialog(this, rows + "Recorde Updated..");
                getFaculty();
                clearText();
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }//end of update
    
    private void addBatch(){
        
        try{
            
            ProgramBean beans = (ProgramBean)JComboProgId.getSelectedItem();
            if(beans == null) return; 
           
            int batchYear = Integer.parseInt(TbatchYear.getText());
            String remarks = remarksArea.getText();
            String batchShift = Encode.shiftEncode(JComboShift.getSelectedItem().toString());
            String batchGroup = Encode.groupEncode(JComboGroup.getSelectedItem().toString());
            
             int row = databaseManager.addBatch(new BatchBean(beans.getProgId(),batchYear,batchShift,batchGroup, remarks));              				
            if(row>=1){
                clearText();
                getBatch();
                JOptionPane.showMessageDialog(this,"INSERTED!");
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }
	
    private void clearText(){
        TbatchYear.setText("");
        TbatchId.setText("");
        remarksArea.setText("");
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        JComboFacId = new javax.swing.JComboBox();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        JComboDeptId = new javax.swing.JComboBox();
        JComboProgId = new javax.swing.JComboBox();
        jLabel4 = new javax.swing.JLabel();
        TbatchId = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        TbatchYear = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        JComboShift = new javax.swing.JComboBox();
        jLabel8 = new javax.swing.JLabel();
        JComboGroup = new javax.swing.JComboBox();
        jLabel10 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        remarksArea = new javax.swing.JTextArea();
        jLabel9 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jList = new javax.swing.JList();
        backButton = new javax.swing.JButton();
        addButton = new javax.swing.JButton();
        updateButton = new javax.swing.JButton();
        deleteButton = new javax.swing.JButton();
        clearButton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Open Sans", 1, 36)); // NOI18N
        jLabel1.setText("BATCH");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 50, -1, 30));

        JComboFacId.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        JComboFacId.setMinimumSize(new java.awt.Dimension(25, 25));
        JComboFacId.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JComboFacIdActionPerformed(evt);
            }
        });
        getContentPane().add(JComboFacId, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 100, 470, 25));

        jLabel2.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel2.setText("FACULTY");
        jLabel2.setMinimumSize(new java.awt.Dimension(25, 25));
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 100, -1, 25));

        jLabel3.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel3.setText("DEPARTMENTS");
        jLabel3.setMinimumSize(new java.awt.Dimension(25, 25));
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 140, -1, 25));

        JComboDeptId.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        JComboDeptId.setMinimumSize(new java.awt.Dimension(25, 25));
        JComboDeptId.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JComboDeptIdActionPerformed(evt);
            }
        });
        getContentPane().add(JComboDeptId, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 140, 470, 25));

        JComboProgId.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        JComboProgId.setMinimumSize(new java.awt.Dimension(25, 25));
        JComboProgId.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JComboProgIdActionPerformed(evt);
            }
        });
        getContentPane().add(JComboProgId, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 180, 470, 25));

        jLabel4.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel4.setText("PROGRAMS");
        jLabel4.setMinimumSize(new java.awt.Dimension(25, 25));
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 180, 70, 20));

        TbatchId.setEditable(false);
        TbatchId.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        TbatchId.setMinimumSize(new java.awt.Dimension(25, 25));
        getContentPane().add(TbatchId, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 210, 60, 25));

        jLabel5.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel5.setText("BATCH ID");
        jLabel5.setMinimumSize(new java.awt.Dimension(25, 25));
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 210, -1, 25));

        jLabel6.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel6.setText("BATCH YEAR");
        jLabel6.setMinimumSize(new java.awt.Dimension(25, 25));
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 250, -1, 20));

        TbatchYear.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        TbatchYear.setMinimumSize(new java.awt.Dimension(25, 25));
        getContentPane().add(TbatchYear, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 250, 60, 25));

        jLabel7.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel7.setText("SHIFT");
        jLabel7.setMinimumSize(new java.awt.Dimension(25, 25));
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 250, 40, 20));

        JComboShift.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        JComboShift.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "MORNING", "EVENING" }));
        JComboShift.setMinimumSize(new java.awt.Dimension(25, 25));
        getContentPane().add(JComboShift, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 250, 110, 20));

        jLabel8.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jLabel8.setText("GROUP");
        jLabel8.setMinimumSize(new java.awt.Dimension(25, 25));
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 250, -1, 20));

        JComboGroup.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        JComboGroup.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "GENERAL", "MEDICAL", "ENGINEERING", "COMMERCE" }));
        JComboGroup.setMinimumSize(new java.awt.Dimension(25, 25));
        getContentPane().add(JComboGroup, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 250, 110, 20));

        jLabel10.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jLabel10.setText("BATCH YEAR");
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 80, 80, 20));

        remarksArea.setColumns(20);
        remarksArea.setFont(new java.awt.Font("Open Sans", 0, 14)); // NOI18N
        remarksArea.setRows(5);
        jScrollPane1.setViewportView(remarksArea);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 280, 470, 192));

        jLabel9.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel9.setText("REMARKS");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 290, -1, -1));

        jList.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jList.addListSelectionListener(new javax.swing.event.ListSelectionListener() {
            public void valueChanged(javax.swing.event.ListSelectionEvent evt) {
                jListValueChanged(evt);
            }
        });
        jScrollPane2.setViewportView(jList);

        getContentPane().add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 100, 170, 370));

        backButton.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        backButton.setText("BACK");
        backButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backButtonActionPerformed(evt);
            }
        });
        getContentPane().add(backButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 480, 110, 24));

        addButton.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        addButton.setText("ADD");
        addButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addButtonActionPerformed(evt);
            }
        });
        getContentPane().add(addButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 480, 110, 24));

        updateButton.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        updateButton.setText("UPDATE");
        updateButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateButtonActionPerformed(evt);
            }
        });
        getContentPane().add(updateButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 480, 110, 24));

        deleteButton.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        deleteButton.setText("DELETE");
        deleteButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteButtonActionPerformed(evt);
            }
        });
        getContentPane().add(deleteButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 480, 80, 24));

        clearButton.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        clearButton.setText("CLEAR");
        clearButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clearButtonActionPerformed(evt);
            }
        });
        getContentPane().add(clearButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 480, 110, 24));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void JComboFacIdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JComboFacIdActionPerformed
        try {
            getDepartment();
        } catch (Exception ex) {
            Logger.getLogger(BatchFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_JComboFacIdActionPerformed

    private void JComboDeptIdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JComboDeptIdActionPerformed
        getProgram();
    }//GEN-LAST:event_JComboDeptIdActionPerformed

    private void JComboProgIdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JComboProgIdActionPerformed
        getBatch();
    }//GEN-LAST:event_JComboProgIdActionPerformed

    private void jListValueChanged(javax.swing.event.ListSelectionEvent evt) {//GEN-FIRST:event_jListValueChanged
        BatchBean bean = (BatchBean) jList.getSelectedValue();
        if(bean==null)return;
        TbatchYear.setText(""+bean.getBatchYear());
        TbatchId.setText(""+bean.getBatchId());
        JComboShift.setSelectedItem(Decode.shiftDecode(bean.getBatchShift()));
        JComboGroup.setSelectedItem(Decode.groupDecode(bean.getBatchGroup()));
        remarksArea.setText(bean.getRemarks());
    }//GEN-LAST:event_jListValueChanged

    private void backButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backButtonActionPerformed
        hide();
    }//GEN-LAST:event_backButtonActionPerformed

    private void addButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addButtonActionPerformed
        addBatch();
    }//GEN-LAST:event_addButtonActionPerformed

    private void updateButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateButtonActionPerformed
        updateBatch();
    }//GEN-LAST:event_updateButtonActionPerformed

    private void deleteButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteButtonActionPerformed
        deleteBatch();
    }//GEN-LAST:event_deleteButtonActionPerformed

    private void clearButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clearButtonActionPerformed
        clearText();
    }//GEN-LAST:event_clearButtonActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(BatchFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(BatchFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(BatchFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(BatchFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new BatchFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox JComboDeptId;
    private javax.swing.JComboBox JComboFacId;
    private javax.swing.JComboBox JComboGroup;
    private javax.swing.JComboBox JComboProgId;
    private javax.swing.JComboBox JComboShift;
    private javax.swing.JTextField TbatchId;
    private javax.swing.JTextField TbatchYear;
    private javax.swing.JButton addButton;
    private javax.swing.JButton backButton;
    private javax.swing.JButton clearButton;
    private javax.swing.JButton deleteButton;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JList jList;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextArea remarksArea;
    private javax.swing.JButton updateButton;
    // End of variables declaration//GEN-END:variables
}
