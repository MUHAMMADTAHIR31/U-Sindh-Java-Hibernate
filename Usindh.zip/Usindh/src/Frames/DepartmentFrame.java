/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Frames;

import BeanClasses.DepartmentBean;
import BeanClasses.FacultyBean;
import BeanClasses.MainWorkPlace;
import DatabaseManager.DatabaseManager;
import java.util.Hashtable;
import java.util.List;
import java.util.Vector;
import javax.swing.JOptionPane;

/**
 *
 * @author Dell
 */
public class DepartmentFrame extends javax.swing.JFrame {

    /**
     * Creates new form DepartmentFrame
     */
    DatabaseManager databaseManager = new DatabaseManager();
    
    public DepartmentFrame() {
        initComponents();
         getFaculty();
    }
    
    private void getFaculty(){
        try{
            List<FacultyBean> faculties = databaseManager.getFaculty();
            facultyIdComboBox.removeAllItems();
            
            for(int i = 0; i < faculties.size(); i++){
                facultyIdComboBox.addItem(faculties.get(i));
            }
        }catch(Exception ee){
            ee.printStackTrace();
            MainWorkPlace.Jpane("Error "+ee.getMessage());
        }
    }
    
    private void getDepartment(){
        
        try{
            FacultyBean beans = (FacultyBean)(facultyIdComboBox.getSelectedItem()); 
            List<DepartmentBean> department = databaseManager.getDepartment(beans.getFacId());
            departmentList.setListData(department.toArray());
            
        }catch(Exception e){
            e.printStackTrace();
        }
    }//end of get
    
    
    private void deleteDepartment(){
        
        DepartmentBean bean=(DepartmentBean)departmentList.getSelectedValue();
        if(bean==null)return;
       
        try{
            int rows=databaseManager.deleteDepartment(bean.getDeptId());
            if(rows>=1){
               getDepartment();
               clearText();
               JOptionPane.showMessageDialog(this,rows+"record removed");
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }//end of delete
    
    private void updateDepartment(){
        
        FacultyBean bean = (FacultyBean)facultyIdComboBox.getSelectedItem();
        int deptId =Integer.parseInt(departmentId.getText());
        String deptName = deptNameTextField.getText();
        String remarks = remarksTextArea.getText();
        
        try{
            int rows = databaseManager.updateDepartment(new DepartmentBean(bean.getFacId(),deptId ,deptName, remarks));
            if(rows >= 1){
                JOptionPane.showMessageDialog(this, rows + "Recorde Updated..");
                getFaculty();
                clearText();
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }//end of updateFaculty
    
    private void addDepartment(){
        
        FacultyBean bean = (FacultyBean)facultyIdComboBox.getSelectedItem();
        String deptName = deptNameTextField.getText();
        String remarks = remarksTextArea.getText();
        
        try{
            int rows = databaseManager.addDepartment(new DepartmentBean(bean.getFacId(),deptName, remarks));
            if(rows >= 1){
                JOptionPane.showMessageDialog(this, rows + "Recorde Addded..");
                getFaculty();
                clearText();
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }//end of add
	
    private void clearText(){
        departmentId.setText("");
        deptNameTextField.setText("");
        remarksTextArea.setText("");
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        facultyIdComboBox = new javax.swing.JComboBox();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        departmentId = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        remarksTextArea = new javax.swing.JTextArea();
        deptNameTextField = new javax.swing.JTextField();
        jScrollPane3 = new javax.swing.JScrollPane();
        departmentList = new javax.swing.JList();
        jLabel6 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        deleteButton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Open Sans", 1, 36)); // NOI18N
        jLabel1.setText("DEPARTMENT");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 30, -1, -1));

        facultyIdComboBox.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        facultyIdComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                facultyIdComboBoxActionPerformed(evt);
            }
        });
        getContentPane().add(facultyIdComboBox, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 100, 480, 25));

        jLabel2.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jLabel2.setText("FACULTY");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 100, -1, 25));

        jLabel3.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jLabel3.setText("DEPT ID");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 140, 50, 25));

        departmentId.setEditable(false);
        departmentId.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        getContentPane().add(departmentId, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 140, 480, 25));

        jLabel4.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jLabel4.setText("DEPT NAME");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 180, 70, 25));

        jLabel5.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jLabel5.setText("REMARKS");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 220, -1, -1));

        remarksTextArea.setColumns(20);
        remarksTextArea.setRows(5);
        jScrollPane4.setViewportView(remarksTextArea);

        getContentPane().add(jScrollPane4, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 220, 480, 180));

        deptNameTextField.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        getContentPane().add(deptNameTextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 180, 480, 25));

        departmentList.addListSelectionListener(new javax.swing.event.ListSelectionListener() {
            public void valueChanged(javax.swing.event.ListSelectionEvent evt) {
                departmentListValueChanged(evt);
            }
        });
        jScrollPane3.setViewportView(departmentList);

        getContentPane().add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 100, 380, 300));

        jLabel6.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jLabel6.setText("DEPARTMENTS");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 80, 100, -1));

        jButton1.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jButton1.setText("UPDATE");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 420, 90, 30));

        jButton2.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jButton2.setText("ADD");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 420, 90, 30));

        jButton3.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jButton3.setText("BACK");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 420, 100, 30));

        jButton5.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jButton5.setText("CLEAR");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton5, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 420, 80, 30));

        deleteButton.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        deleteButton.setText("Delete");
        deleteButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteButtonActionPerformed(evt);
            }
        });
        getContentPane().add(deleteButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(853, 410, 90, 40));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void facultyIdComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_facultyIdComboBoxActionPerformed
        getDepartment();
    }//GEN-LAST:event_facultyIdComboBoxActionPerformed

    private void departmentListValueChanged(javax.swing.event.ListSelectionEvent evt) {//GEN-FIRST:event_departmentListValueChanged
        DepartmentBean beans = (DepartmentBean) departmentList.getSelectedValue();
        if(beans == null)return;
        departmentId.setText(""+beans.getDeptId());
        deptNameTextField.setText(beans.getDeptName());
        remarksTextArea.setText(beans.getRemarks());
    }//GEN-LAST:event_departmentListValueChanged

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        updateDepartment();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        addDepartment();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        hide();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        clearText();
    }//GEN-LAST:event_jButton5ActionPerformed

    private void deleteButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteButtonActionPerformed
        deleteDepartment();
    }//GEN-LAST:event_deleteButtonActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(DepartmentFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(DepartmentFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(DepartmentFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(DepartmentFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new DepartmentFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton deleteButton;
    private javax.swing.JTextField departmentId;
    private javax.swing.JList departmentList;
    private javax.swing.JTextField deptNameTextField;
    private javax.swing.JComboBox facultyIdComboBox;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton5;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTextArea remarksTextArea;
    // End of variables declaration//GEN-END:variables
}
