/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Frames;

import BeanClasses.*;
import DatabaseManager.DatabaseManager;
import java.util.List;
import java.util.Vector;
import javax.swing.JOptionPane;

/**
 *
 * @author Dell
 */
public class StudentFrame extends javax.swing.JFrame {

    DatabaseManager databaseManager= new DatabaseManager();
    
    public StudentFrame() {
        initComponents();
        getFaculty();
    }
    
    private void getFaculty(){
        try{
            
            List<FacultyBean> faculties = databaseManager.getFaculty();
            facComboBox.removeAllItems();

            for(int i = 0; i < faculties.size(); i++){
                facComboBox.addItem(faculties.get(i));
            }

        }catch(Exception ee){
            ee.printStackTrace();
            MainWorkPlace.Jpane("Error "+ee);
        }
    }
    /////***** getFaculty Load *****/////


    /////***** getDepartment Load *****/////
    private void getDepartment(){
            FacultyBean beans = (FacultyBean)(facComboBox.getSelectedItem());
            if(beans == null)return;

            try{
                   List<DepartmentBean> dept = databaseManager.getDepartment(beans.getFacId());
                    deptComboBox.removeAllItems();

                    for(int i = 0; i < dept.size(); i++){
                            deptComboBox.addItem(dept.get(i));
                    }

            }catch(Exception ee){
                    ee.printStackTrace();
                    MainWorkPlace.Jpane("Error "+ee);
            }
    }
    /////***** getDepartment Load *****/////


    /////***** getProgram Load *****/////
    private void getProgram(){
            DepartmentBean beans = (DepartmentBean)(deptComboBox.getSelectedItem());
            if(beans == null)return;

            try{
                    List<ProgramBean> program = databaseManager.getProgram(beans.getDeptId());
                    progComboBox.removeAllItems();

                    for(int i = 0; i < program.size(); i++){
                            progComboBox.addItem(program.get(i));
                    }

            }catch(Exception ee){
                    ee.printStackTrace();
                    MainWorkPlace.Jpane("Error "+ee);
            }
    }
    /////***** getProgram Load *****/////


    /////***** getBatch Load *****/////
    private void getBatch(){
        
        ProgramBean beans = (ProgramBean)(progComboBox.getSelectedItem());
        if(beans == null)return;

            try{
                    List<BatchBean> batch = databaseManager.getBatch(beans.getProgId());
                    batchComboBox.removeAllItems();

                    for(int i = 0; i < batch.size(); i++){
                            batchComboBox.addItem(batch.get(i));
                    }
       }catch(Exception ee){
                    ee.printStackTrace();
                    MainWorkPlace.Jpane("Error "+ee);
            }

    }
    /////***** getBatch Load *****/////


    /////***** Jlist Load *****/////
    private void getStudent(){
            BatchBean beans = (BatchBean)(batchComboBox.getSelectedItem());
            if(beans == null)return;

            try{
                    List<StudentRegistrationBean> std = databaseManager.getStudentRegistration(beans.getBatchId());
                    rollNoList.setListData(std.toArray());
                }catch(Exception ee){
                    ee.printStackTrace();
                    MainWorkPlace.Jpane("Error "+ee);
            }
    }
    /////***** Jlist Load *****/////



    /////***** getShift & Group Load *****/////
    private void getShiftGroup(){
        BatchBean bean = (BatchBean)(batchComboBox.getSelectedItem());
        if(bean == null)return;
        this.shiftComboBox.setSelectedItem(Decode.shiftDecode(bean.getBatchShift()));
        this.groupComboBox.setSelectedItem(Decode.groupDecode(bean.getBatchGroup()));
    }
    /////***** getShift & Group Load *****/////

private void addStudents(){
    
       BatchBean bean=(BatchBean)batchComboBox.getSelectedItem();
       if(bean==null)return;
       
       String name=stdNameTextField.getText();
       String fname=fNameTextField.getText();
       String surname=surnameTextField.getText();
       String rollno=rollNoTextField.getText();
       String remarks=remarksTextArea.getText();
       String gender = genderComboBox.getSelectedItem()+"";
       try{
           int rows=databaseManager.addStudentRegistration(new StudentRegistrationBean(bean.getBatchId(), name, fname, surname, rollno, gender, remarks));
           if(rows>=1){
               getStudent();
               clear();
               JOptionPane.showMessageDialog(this, rows+"record saved");
           }
       }catch(Exception e){
           e.printStackTrace();
       }
   }
    
    private void updateStudent(){
    
        StudentRegistrationBean bean=(StudentRegistrationBean)rollNoList.getSelectedValue();
        if(bean==null)return;
       
       String name=stdNameTextField.getText();
       int stdId=Integer.parseInt(stdIdTextField.getText());
       String fname=fNameTextField.getText();
       String surname=surnameTextField.getText();
       String rollno=rollNoTextField.getText();
       String remarks=remarksTextArea.getText();
       String gender = Encode.genderEncode(""+genderComboBox.getSelectedItem());
       
       try{
          int rows=databaseManager.updateStudentRegistration(new StudentRegistrationBean(bean.getBatchId(),stdId, name, fname, surname, rollno, gender, remarks));
           if(rows>=1){
               getStudent();
               clear();
               JOptionPane.showMessageDialog(this, rows+"record Midified");
           }
       }catch(Exception e){
           e.printStackTrace();
       }
   }

private void deleteStudent(){
       StudentRegistrationBean bean=(StudentRegistrationBean)rollNoList.getSelectedValue();
       if(bean==null)return;
       try{
           int rows=databaseManager.deleteStudentRegistration(bean.getStuId());
           if(rows>=1){
               getStudent();
               clear();
               JOptionPane.showMessageDialog(this,rows+"record removed");
           }
       }catch(Exception e){
            e.printStackTrace();
        }
} 
   


    private void clear(){
//        stdIdTextField.setText("");
        stdNameTextField.setText("");
        fNameTextField.setText("");
        surnameTextField.setText("");
        rollNoTextField.setText("");
        //genderTextField.setText("");
        remarksTextArea.setText("");
    } 
    
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        facComboBox = new javax.swing.JComboBox();
        jLabel3 = new javax.swing.JLabel();
        deptComboBox = new javax.swing.JComboBox();
        jLabel4 = new javax.swing.JLabel();
        progComboBox = new javax.swing.JComboBox();
        jLabel5 = new javax.swing.JLabel();
        batchComboBox = new javax.swing.JComboBox();
        shiftComboBox = new javax.swing.JComboBox();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        groupComboBox = new javax.swing.JComboBox();
        jLabel15 = new javax.swing.JLabel();
        stdNameTextField = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        fNameTextField = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        surnameTextField = new javax.swing.JTextField();
        jLabel18 = new javax.swing.JLabel();
        rollNoTextField = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        rollNoList = new javax.swing.JList();
        jScrollPane1 = new javax.swing.JScrollPane();
        remarksTextArea = new javax.swing.JTextArea();
        exitButton = new javax.swing.JButton();
        addButton = new javax.swing.JButton();
        updateButton = new javax.swing.JButton();
        deleteButton = new javax.swing.JButton();
        clearButton = new javax.swing.JButton();
        jLabel19 = new javax.swing.JLabel();
        genderComboBox = new javax.swing.JComboBox<String>();
        jLabel6 = new javax.swing.JLabel();
        stdIdTextField = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Open Sans", 1, 24)); // NOI18N
        jLabel1.setText("STUDENT REGISTRATION");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 20, -1, -1));

        jLabel2.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jLabel2.setText("FACULTY");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(97, 71, -1, 20));

        facComboBox.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        facComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                facComboBoxActionPerformed(evt);
            }
        });
        getContentPane().add(facComboBox, new org.netbeans.lib.awtextra.AbsoluteConstraints(167, 71, 540, -1));

        jLabel3.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jLabel3.setText("DEPARTMENT");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(67, 111, -1, 20));

        deptComboBox.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        deptComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deptComboBoxActionPerformed(evt);
            }
        });
        getContentPane().add(deptComboBox, new org.netbeans.lib.awtextra.AbsoluteConstraints(167, 111, 540, -1));

        jLabel4.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jLabel4.setText("PROGRAM");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(87, 151, -1, -1));

        progComboBox.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        progComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                progComboBoxActionPerformed(evt);
            }
        });
        getContentPane().add(progComboBox, new org.netbeans.lib.awtextra.AbsoluteConstraints(167, 151, 540, -1));

        jLabel5.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jLabel5.setText("BATCH YEAR");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(87, 191, -1, 30));

        batchComboBox.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        batchComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                batchComboBoxActionPerformed(evt);
            }
        });
        getContentPane().add(batchComboBox, new org.netbeans.lib.awtextra.AbsoluteConstraints(167, 191, 70, 30));

        shiftComboBox.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        shiftComboBox.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "MORNING", "EVENING" }));
        shiftComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                shiftComboBoxActionPerformed(evt);
            }
        });
        getContentPane().add(shiftComboBox, new org.netbeans.lib.awtextra.AbsoluteConstraints(287, 191, 90, 30));

        jLabel7.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jLabel7.setText("SHIFT");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(247, 191, 40, 30));

        jLabel8.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jLabel8.setText("GROUP");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(387, 191, 50, 30));

        groupComboBox.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        groupComboBox.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "GENERAL", "ENGINEERING", "MEDICAL", "COMMERCE" }));
        groupComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                groupComboBoxActionPerformed(evt);
            }
        });
        getContentPane().add(groupComboBox, new org.netbeans.lib.awtextra.AbsoluteConstraints(437, 191, 90, 30));

        jLabel15.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jLabel15.setText("Name");
        getContentPane().add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(117, 281, 40, 25));

        stdNameTextField.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        getContentPane().add(stdNameTextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(167, 281, 210, 25));

        jLabel16.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jLabel16.setText("Father Name");
        getContentPane().add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(77, 321, 80, 25));

        fNameTextField.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        getContentPane().add(fNameTextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(167, 321, 210, 25));

        jLabel17.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jLabel17.setText("Surname");
        getContentPane().add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(97, 361, -1, 25));

        surnameTextField.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        getContentPane().add(surnameTextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(167, 361, 210, 25));

        jLabel18.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jLabel18.setText("Roll No.");
        getContentPane().add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(107, 241, 60, 25));

        rollNoTextField.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        rollNoTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rollNoTextFieldActionPerformed(evt);
            }
        });
        getContentPane().add(rollNoTextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 240, 210, 25));

        jLabel9.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jLabel9.setText("Remarks");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(97, 401, -1, -1));

        jLabel10.setFont(new java.awt.Font("Open Sans", 1, 14)); // NOI18N
        jLabel10.setText("ROLL NO.");
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(747, 51, -1, -1));

        rollNoList.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        rollNoList.addListSelectionListener(new javax.swing.event.ListSelectionListener() {
            public void valueChanged(javax.swing.event.ListSelectionEvent evt) {
                rollNoListValueChanged(evt);
            }
        });
        jScrollPane2.setViewportView(rollNoList);

        getContentPane().add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(717, 71, 150, 440));

        remarksTextArea.setColumns(20);
        remarksTextArea.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        remarksTextArea.setRows(5);
        jScrollPane1.setViewportView(remarksTextArea);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(167, 401, 540, 110));

        exitButton.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        exitButton.setText("EXIT");
        exitButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitButtonActionPerformed(evt);
            }
        });
        getContentPane().add(exitButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(577, 531, 130, 30));

        addButton.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        addButton.setText("ADD");
        addButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addButtonActionPerformed(evt);
            }
        });
        getContentPane().add(addButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(167, 531, 110, 30));

        updateButton.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        updateButton.setText("UPDATE");
        updateButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateButtonActionPerformed(evt);
            }
        });
        getContentPane().add(updateButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(297, 531, 120, 30));

        deleteButton.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        deleteButton.setText("DELETE");
        deleteButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteButtonActionPerformed(evt);
            }
        });
        getContentPane().add(deleteButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(777, 531, 90, 30));

        clearButton.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        clearButton.setText("CLEAR");
        clearButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clearButtonActionPerformed(evt);
            }
        });
        getContentPane().add(clearButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(437, 531, 120, 30));

        jLabel19.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jLabel19.setText("Gender");
        getContentPane().add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(387, 361, 60, 25));

        genderComboBox.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        genderComboBox.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "MALE", "FEMALE" }));
        getContentPane().add(genderComboBox, new org.netbeans.lib.awtextra.AbsoluteConstraints(437, 361, 90, 25));

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel6.setText("Student ID");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 244, 70, 20));

        stdIdTextField.setEditable(false);
        stdIdTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                stdIdTextFieldActionPerformed(evt);
            }
        });
        getContentPane().add(stdIdTextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 240, 120, 30));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void facComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_facComboBoxActionPerformed
        getDepartment();
    }//GEN-LAST:event_facComboBoxActionPerformed

    private void deptComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deptComboBoxActionPerformed
        getProgram();
    }//GEN-LAST:event_deptComboBoxActionPerformed

    private void progComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_progComboBoxActionPerformed
        getBatch();
    }//GEN-LAST:event_progComboBoxActionPerformed

    private void batchComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_batchComboBoxActionPerformed
        getShiftGroup();
        getStudent();
    }//GEN-LAST:event_batchComboBoxActionPerformed

    private void shiftComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_shiftComboBoxActionPerformed

    }//GEN-LAST:event_shiftComboBoxActionPerformed

    private void groupComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_groupComboBoxActionPerformed

    }//GEN-LAST:event_groupComboBoxActionPerformed

    private void rollNoTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rollNoTextFieldActionPerformed

    }//GEN-LAST:event_rollNoTextFieldActionPerformed

    private void rollNoListValueChanged(javax.swing.event.ListSelectionEvent evt) {//GEN-FIRST:event_rollNoListValueChanged

        StudentRegistrationBean beans = (StudentRegistrationBean)(rollNoList.getSelectedValue());
        if(beans == null)return;

        stdIdTextField.setText(""+beans.getStuId());
        stdNameTextField.setText(beans.getStuName());
        fNameTextField.setText(beans.getStuFname());
        surnameTextField.setText(beans.getStuSurname());
        rollNoTextField.setText(beans.getStuRollno());
        remarksTextArea.setText(beans.getRemarks());
        genderComboBox.setSelectedItem(Decode.genderDecode(beans.getGender()));

        // TODO add your handling code here:
    }//GEN-LAST:event_rollNoListValueChanged

    private void exitButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitButtonActionPerformed
        dispose();
    }//GEN-LAST:event_exitButtonActionPerformed

    private void addButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addButtonActionPerformed
        addStudents();
    }//GEN-LAST:event_addButtonActionPerformed

    private void updateButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateButtonActionPerformed
        updateStudent();
    }//GEN-LAST:event_updateButtonActionPerformed

    private void deleteButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteButtonActionPerformed
        deleteStudent();
    }//GEN-LAST:event_deleteButtonActionPerformed

    private void clearButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clearButtonActionPerformed
        clear();
    }//GEN-LAST:event_clearButtonActionPerformed

    private void stdIdTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_stdIdTextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_stdIdTextFieldActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(StudentFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(StudentFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(StudentFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(StudentFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new StudentFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton addButton;
    private javax.swing.JComboBox batchComboBox;
    private javax.swing.JButton clearButton;
    private javax.swing.JButton deleteButton;
    private javax.swing.JComboBox deptComboBox;
    private javax.swing.JButton exitButton;
    private javax.swing.JTextField fNameTextField;
    private javax.swing.JComboBox facComboBox;
    private javax.swing.JComboBox<String> genderComboBox;
    private javax.swing.JComboBox groupComboBox;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JComboBox progComboBox;
    private javax.swing.JTextArea remarksTextArea;
    private javax.swing.JList rollNoList;
    private javax.swing.JTextField rollNoTextField;
    private javax.swing.JComboBox shiftComboBox;
    private javax.swing.JTextField stdIdTextField;
    private javax.swing.JTextField stdNameTextField;
    private javax.swing.JTextField surnameTextField;
    private javax.swing.JButton updateButton;
    // End of variables declaration//GEN-END:variables
}
