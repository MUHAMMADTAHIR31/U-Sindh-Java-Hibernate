/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BeanClasses;

/**
 *
 * @author Salman Ahmed
 */
public class DepartmentBean {
    
    private int facId;
    private int deptId;
    private String deptName;
    private String remarks;
    
    public DepartmentBean(){}
    
    public DepartmentBean(int facId,int deptId,String deptName,String remarks){
        
        this.deptId=deptId;
        this.deptName=deptName;
        this.facId=facId;
        this.remarks=remarks;
    }
    
    public DepartmentBean(int facId,String deptName,String remarks){
        
        this.deptId=deptId;
        this.deptName=deptName;
        this.facId=facId;
        this.remarks=remarks;
    }
    
    public int getFacId() {
        return facId;
    }

    public void setFacId(int facId) {
        this.facId = facId;
    }
  

    public void setDeptId(int deptId){
            this.deptId = deptId;
    }

    public void setDeptName(String deptName){
            this.deptName = deptName;
    }

    public void setRemarks(String remarks){
            this.remarks = remarks;
    }
    
    public int getDeptId(){
            return deptId;
    }

    public String getDeptName(){
            return deptName;
    }

    public String getRemarks(){
            return remarks;
    }

    public String toString(){
            return deptName;
    }
}
