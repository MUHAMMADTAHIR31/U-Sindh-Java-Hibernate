/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BeanClasses;

/**
 *
 * @author Salman Ahmed
 */
public class Encode {
    public static String shiftEncode(String shift){
        if(shift.equals("MORNING"))return "M";
        if(shift.equals("EVENING"))return "E";
        if(shift.equals("NOON"))return "N";
        return shift;
    }
	
    public static String groupEncode(String group){
        if(group.equals("GENERAL"))return "GNRL";
        if(group.equals("ENGINEERING"))return "E";
        if(group.equals("MEDICAL"))return "M";
        if(group.equals("COMMERCE"))return "C";
        return group;
    }
	
    public static String typeEncode(String type){
        if(type.equals("REGULAR"))return "R";
        if(type.equals("IMPROVER/FAILURE"))return "I";

        return type;
    }

    public static String statusEncode(String status){
        if(status.equals("TEMPORARY"))return "T";
        if(status.equals("LEGAL"))return "L";

        return status;
    }
    
    public static String isCreditableEncode(String isCreditable){
        if(isCreditable.equals("YES"))return "Y";
        if(isCreditable.equals("NO"))return "N";
        return isCreditable;
    }
    
    public static String subjectType(String subType){
        if(subType.equals("GENERAL"))return "G";
        if(subType.equals("ELECTIVE"))return "E";
        return subType;
    }
    
    public static String genderEncode(String gender){
        if(gender.equals("FEMALE"))return "F";
        if(gender.equals("MALE"))return "M";
        return gender;
    }
}
