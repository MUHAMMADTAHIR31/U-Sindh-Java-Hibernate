/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BeanClasses;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * @author Salman Ahmed
 */
public class Decode {
    public static String shiftDecode(String shift){
        if(shift.equals("M"))return "MORNING";
        if(shift.equals("E"))return "EVENING";
        if(shift.equals("N"))return "NOON";

        return shift;
    }

    public static String groupDecode(String group){
        if(group.equals("GNRL"))return "GENERAL";
        if(group.equals("E"))return "ENGINEERING";
        if(group.equals("M"))return "MEDICAL";
        if(group.equals("C"))return "COMMERCE";

        return group;
    }

    public static String typeDecode(String type){
        if(type.equals("R"))return "REGULAR";
        if(type.equals("I"))return "IMPROVER/FAILURE";
        return type;
    }

    public static String statusDecode(String status){
        if(status.equals("T"))return "TEMPORARY";
        if(status.equals("L"))return "LEGAL";
        return status;
    }

    public static String getPartDecode(String part){

   if(part.trim().equalsIgnoreCase("1"))part="I";
   if(part.trim().equalsIgnoreCase("2"))part="II";
   if(part.trim().equalsIgnoreCase("3"))part="III";
   if(part.trim().equalsIgnoreCase("4"))part="IV";
   if(part.trim().equalsIgnoreCase("5"))part="V";
   if(part.trim().equalsIgnoreCase("6"))part="VI";
   if(part.trim().equalsIgnoreCase("7"))part="VII";

   return part;
}//end method

    
public static String dateFormat(Date date){
        if(date==null)return "";
        
        SimpleDateFormat d=new SimpleDateFormat("dd-MMM-yyyy");
        String str=d.format(date);
        return str;
    }    

    public static String isCreditableDecode(String isCreditable){
        if(isCreditable.equals("Y"))return "YES";
        if(isCreditable.equals("N"))return "NO";

        return isCreditable;
    }
    
    
    public static String subjectType(String subType){
        if(subType.equals("G"))return "GENERAL";
        if(subType.equals("E"))return "ELECTIVE";
        return subType;
    }
    
    public static String genderDecode(String gender){
        if(gender.equals("M"))return "MALE";
        if(gender.equals("F"))return "FEMALE";
        return gender;
    }
    
}
