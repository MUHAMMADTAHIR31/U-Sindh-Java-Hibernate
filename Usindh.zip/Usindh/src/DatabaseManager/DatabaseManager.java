/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DatabaseManager;

import BeanClasses.*;
import java.util.*;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;


/**
 *
 * @author Salman Ahmed
 */
public class DatabaseManager implements DBManagerInterface{
    
   private static SessionFactory sessionFactory; 
   
    public DatabaseManager(){
        try {
            sessionFactory = new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
        } catch (Throwable ex) { 
            System.err.println("Failed to create sessionFactory object." + ex);
            throw new ExceptionInInitializerError(ex); 
        }
    }

    public List<FacultyBean> getFaculty() {
        Session session = sessionFactory.openSession();
        Transaction tx = null;
	List faculties = null;
        try {
            tx = session.beginTransaction();
            faculties = session.createQuery("FROM FacultyBean").list(); 
            tx.commit();
            
        } catch (HibernateException e) {
            if (tx!=null) tx.rollback();
            e.printStackTrace(); 
        } finally {
            session.close(); 
        }
        return faculties;
    }//End of getFaculty
    
   @Override
    public int deleteFaculty(int facId) {
        Session session = sessionFactory.openSession();
        Transaction tx = null;

        try{
           tx = session.beginTransaction();
           FacultyBean bean = (FacultyBean)session.get(FacultyBean.class, facId); 
           session.delete(bean); 

           tx.commit();

        } catch (HibernateException e) {
           if (tx!=null) tx.rollback();
           e.printStackTrace(); 
        } finally {
           session.close(); 
        }
        return 1;
    }//End of deleteFaculty

    @Override
    public int updateFaculty(FacultyBean faculty) {
        Session session = sessionFactory.openSession();
        Transaction tx = null;

        try {
            tx = session.beginTransaction();
            session.update(faculty); 
            tx.commit();

        } catch (HibernateException e) {
           if (tx!=null) tx.rollback();
           e.printStackTrace(); 
        } finally {
           session.close(); 
        }
        return 1;
    }//End of updateFaculty

   @Override
    public int addFaculty(FacultyBean faculty) {
        Session session = sessionFactory.openSession();
        Transaction tx = null;

        try{
           tx = session.beginTransaction();
           session.save(faculty); 
           tx.commit();
           
        } catch (HibernateException e) {
           if (tx!=null) tx.rollback();
           e.printStackTrace(); 
        } finally {
           session.close(); 
        }
        return 1;
    }//End addFaculty
    
//   @Override
//    public FacultyBean getFacultyById(int facId) {
//        Session session = sessionFactory.openSession();
//        Transaction tx = null;
//	FacultyBean facultyBean = null;
//        try {
//           tx = session.beginTransaction();
//           facultyBean = (FacultyBean)session.get(FacultyBean.class, facId); 
//
//           tx.commit();
//
//        } catch (HibernateException e) {
//           if (tx!=null) tx.rollback();
////           e.printStackTrace(); 
//        } finally {
//           session.close(); 
//        }
//        return facultyBean;
//    }//End getFacultyById
    
   @Override
      public List<DepartmentBean> getDepartment(int facId) {
        Session session = sessionFactory.openSession();
        Transaction tx = null;
	List depart = null;
        try {
            tx = session.beginTransaction();
            depart = session.createQuery("FROM DepartmentBean where fac_id="+facId ).list(); 
            tx.commit();
            
        } catch (HibernateException e) {
            if (tx!=null) tx.rollback();
            e.printStackTrace(); 
        } finally {
            session.close(); 
        }
        return depart;
    }//End of getFaculty
    
   @Override
    public int deleteDepartment(int deptId) {
        Session session = sessionFactory.openSession();
        Transaction tx = null;

        try{
           tx = session.beginTransaction();
           DepartmentBean bean = (DepartmentBean)session.get(DepartmentBean.class, deptId); 
           session.delete(bean); 

           tx.commit();

        } catch (HibernateException e) {
           if (tx!=null) tx.rollback();
           e.printStackTrace(); 
        } finally {
           session.close(); 
        }
        return 1;
    }//End of deleteFaculty

    @Override
    public int updateDepartment(DepartmentBean dept) {
        Session session = sessionFactory.openSession();
        Transaction tx = null;

        try {
            tx = session.beginTransaction();
            session.update(dept); 
            tx.commit();

        } catch (HibernateException e) {
           if (tx!=null) tx.rollback();
             e.printStackTrace(); 
        } finally {
           session.close(); 
        }
        return 1;
    }//End of updateFaculty

   @Override
    public int addDepartment(DepartmentBean depart) {
        Session session = sessionFactory.openSession();
        Transaction tx = null;

        try{
           tx = session.beginTransaction();
           session.save(depart); 
           tx.commit();
           
        } catch (HibernateException e) {
           if (tx!=null) tx.rollback();
           e.printStackTrace(); 
        } finally {
           session.close(); 
        }
        return 1;
    }//End addFaculty
//    
//   @Override
//    public DepartmentBean getDepartmentId(int deptId) {
//        
//        Session session = sessionFactory.openSession();
//        Transaction tx = null;
//	DepartmentBean DepartBean = null;
//        
//        try {
//           tx = session.beginTransaction();
//           DepartBean = (DepartmentBean)session.get(DepartmentBean.class, deptId); 
//           tx.commit();
//        } catch (HibernateException e) {
//           if (tx!=null) tx.rollback();
//           e.printStackTrace(); 
//        } finally {
//           session.close(); 
//        }
//        return DepartBean;
//    }//End getFacultyById
    
    
   @Override
    public  List<ProgramBean> getProgram(int deptId) {
          
        Session session = sessionFactory.openSession();
        Transaction tx = null;
	List depart = null;
        try {
            tx = session.beginTransaction();
            depart = session.createQuery("FROM ProgramBean where dept_id="+deptId).list(); 
            tx.commit();
            
        } catch (HibernateException e) {
            if (tx!=null) tx.rollback();
            e.printStackTrace(); 
        } finally {
            session.close(); 
        }
        return depart;
    }//End of get
    
    @Override
    public int deleteProgram(int progId) {
        Session session = sessionFactory.openSession();
        Transaction tx = null;

        try{
           tx = session.beginTransaction();
           ProgramBean bean = (ProgramBean)session.get(ProgramBean.class, progId); 
           session.delete(bean); 

           tx.commit();
        } catch (HibernateException e) {
           if (tx!=null) tx.rollback();
           e.printStackTrace(); 
        } finally {
           session.close(); 
        }
        return 1;
    }//End of deleteFaculty

    @Override
    public int updateProgram(ProgramBean program) {
        Session session = sessionFactory.openSession();
        Transaction tx = null;

        try {
            tx = session.beginTransaction();
            session.update(program); 
            tx.commit();

        } catch (HibernateException e) {
           if (tx!=null) tx.rollback();
             e.printStackTrace(); 
        } finally {
           session.close(); 
        }
        return 1;
    }//End of updateFaculty

    @Override
    public int addProgram(ProgramBean program) {
        Session session = sessionFactory.openSession();
        Transaction tx = null;

        try{
           tx = session.beginTransaction();
           session.save(program); 
           tx.commit();
           
        } catch (HibernateException e) {
           if (tx!=null) tx.rollback();
           e.printStackTrace(); 
        } finally {
           session.close(); 
        }
        return 1;
    }//End addFaculty
    
    @Override
    public  List<BatchBean> getBatch(int progId) {
          
        Session session = sessionFactory.openSession();
        Transaction tx = null;
	List depart = null;
        try {
            tx = session.beginTransaction();
            depart = session.createQuery("FROM BatchBean where prog_id="+progId).list(); 
            tx.commit();
            
        } catch (HibernateException e) {
            if (tx!=null) tx.rollback();
            e.printStackTrace(); 
        } finally {
            session.close(); 
        }
        return depart;
    }//End of get
    
    @Override
    public int deleteBatch(int batchId) {
        Session session = sessionFactory.openSession();
        Transaction tx = null;

        try{
           tx = session.beginTransaction();
           BatchBean bean = (BatchBean)session.get(BatchBean.class, batchId); 
           session.delete(bean); 

           tx.commit();
        } catch (HibernateException e) {
           if (tx!=null) tx.rollback();
           e.printStackTrace(); 
        } finally {
           session.close(); 
        }
        return 1;
    }//End of deleteFaculty

    @Override
    public int updateBatch(BatchBean batch) {
        Session session = sessionFactory.openSession();
        Transaction tx = null;

        try {
            tx = session.beginTransaction();
            session.update(batch); 
            tx.commit();

        } catch (HibernateException e) {
           if (tx!=null) tx.rollback();
             e.printStackTrace(); 
        } finally {
           session.close(); 
        }
        return 1;
    }//End of updateFaculty

    @Override
    public int addBatch(BatchBean batch) {
        Session session = sessionFactory.openSession();
        Transaction tx = null;

        try{
           tx = session.beginTransaction();
           session.save(batch); 
           tx.commit();
           
        } catch (HibernateException e) {
           if (tx!=null) tx.rollback();
           e.printStackTrace(); 
        } finally {
           session.close(); 
        }
        return 1;
    }//End add
    
    @Override
    public  List<StudentRegistrationBean> getStudentRegistration(int batchId) {
          
        Session session = sessionFactory.openSession();
        Transaction tx = null;
	List depart = null;
        try {
            tx = session.beginTransaction();
            depart = session.createQuery("FROM StudentRegistrationBean where batch_id="+batchId).list(); 
            tx.commit();
            
        } catch (HibernateException e) {
            if (tx!=null) tx.rollback();
            e.printStackTrace(); 
        } finally {
            session.close(); 
        }
        return depart;
    }//End of get
    
    @Override
    public int deleteStudentRegistration(int stdId) {
        Session session = sessionFactory.openSession();
        Transaction tx = null;

        try{
           tx = session.beginTransaction();
           StudentRegistrationBean bean = (StudentRegistrationBean)session.get(StudentRegistrationBean.class, stdId); 
           session.delete(bean); 

           tx.commit();
        } catch (HibernateException e) {
           if (tx!=null) tx.rollback();
           e.printStackTrace(); 
        } finally {
           session.close(); 
        }
        return 1;
    }//End of deleteFaculty

    @Override
    public int updateStudentRegistration(StudentRegistrationBean student) {
        Session session = sessionFactory.openSession();
        Transaction tx = null;

        try {
            tx = session.beginTransaction();
            session.update(student); 
            tx.commit();

        } catch (HibernateException e) {
           if (tx!=null) tx.rollback();
             e.printStackTrace(); 
        } finally {
           session.close(); 
        }
        return 1;
    }//End of updateFaculty

    @Override
    public int addStudentRegistration(StudentRegistrationBean student) {
        Session session = sessionFactory.openSession();
        Transaction tx = null;

        try{
           tx = session.beginTransaction();
           session.save(student); 
           tx.commit();
           
        } catch (HibernateException e) {
           if (tx!=null) tx.rollback();
           e.printStackTrace(); 
        } finally {
           session.close(); 
        }
        return 1;
    }//End addFaculty
}//end class
