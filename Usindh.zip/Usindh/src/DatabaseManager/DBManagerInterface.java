package DatabaseManager;

import BeanClasses.BatchBean;
import BeanClasses.DepartmentBean;
import java.util.List;
import BeanClasses.FacultyBean;
import BeanClasses.ProgramBean;
import BeanClasses.StudentRegistrationBean;

interface DBManagerInterface{
    
    public List<FacultyBean> getFaculty();
    public int  deleteFaculty(int facId);
    public int updateFaculty(FacultyBean faculty);
    public int addFaculty(FacultyBean faculty);
    
    public List<DepartmentBean> getDepartment(int facId);
    public int  deleteDepartment(int deptId);
    public int updateDepartment(DepartmentBean depart);
    public int addDepartment(DepartmentBean depart);
    
    public List<ProgramBean> getProgram(int deptId);
    public int  deleteProgram(int progId);
    public int updateProgram(ProgramBean depart);
    public int addProgram(ProgramBean depart);
    
    public List<BatchBean> getBatch(int progId);
    public int  deleteBatch(int batchId);
    public int updateBatch(BatchBean batch);
    public int addBatch(BatchBean batch);
    
    public List<StudentRegistrationBean> getStudentRegistration(int batchId);
    public int  deleteStudentRegistration(int stdId);
    public int updateStudentRegistration(StudentRegistrationBean student);
    public int addStudentRegistration(StudentRegistrationBean student);
}//End of interface
